package com.example.compicprogtamming

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.example.compicprogtamming.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.apply {
            naviView.setNavigationItemSelectedListener {
                OnSelect(it)
            }
            open.setOnClickListener{
                drawer.openDrawer(GravityCompat.START)
            }
        }
    }
    fun OnSelect(item: MenuItem):Boolean{
        when(item.itemId){
            R.id.crVar ->{
                //закрываю drawerLayout
                binding.drawer.closeDrawer(GravityCompat.START)
                //берем своё диалоговое окно
                val mDialogView = LayoutInflater.from(this).inflate(R.layout.menu_cr_var, null);
                //AlertDialogBuilder
                val mBuilder = AlertDialog.Builder(this)
                    .setView(mDialogView)
                    .setTitle("Var Creation Form")
                //показать окно алерта
                val mAlertDialog = mBuilder.show()
                //кнопка создания блока на AlertDialog
                val mAlertDialogButton = mDialogView.findViewById<Button>(R.id.dialogCreateButton)
                val mAlertDialogEditTextName = mDialogView.findViewById<EditText>(R.id.crVarName)
                val mAlertDialogEditTextValue = mDialogView.findViewById<EditText>(R.id.crVarValue)
                mAlertDialogButton.setOnClickListener(){
                    mAlertDialog.dismiss()
                    val varName = mAlertDialogEditTextName.text.toString()
                    val varValue = mAlertDialogEditTextValue.text.toString()
                    Toast.makeText(this, varName + " = " + varValue, Toast.LENGTH_LONG).show()
                }

            }
        }
        binding.drawer.closeDrawer(GravityCompat.START)
        return true
    }

//    private var simpleCallBack = object : ItemTouchHelper.SimpleCallback(){
//        override fun onMove(
//            recyclerView: RecyclerView,
//            viewHolder: RecyclerView.ViewHolder,
//            target: RecyclerView.ViewHolder
//        ): Boolean {
//            TODO("Not yet implemented")
//        }
//
//        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
//
//        }
//    }
}